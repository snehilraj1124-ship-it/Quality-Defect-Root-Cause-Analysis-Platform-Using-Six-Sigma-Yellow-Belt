from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "defectiq-demo"
DB = "defectiq.db"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS processes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        department TEXT NOT NULL,
        owner TEXT NOT NULL,
        units INTEGER NOT NULL,
        defects INTEGER NOT NULL,
        target_rate REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS defects(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        process_id INTEGER NOT NULL,
        defect_type TEXT NOT NULL,
        description TEXT NOT NULL,
        severity TEXT NOT NULL,
        occurrence INTEGER NOT NULL,
        impact_cost REAL NOT NULL,
        detected_at TEXT NOT NULL,
        FOREIGN KEY(process_id) REFERENCES processes(id)
    );
    CREATE TABLE IF NOT EXISTS causes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        defect_id INTEGER NOT NULL,
        category TEXT NOT NULL,
        cause TEXT NOT NULL,
        evidence TEXT NOT NULL,
        likelihood TEXT NOT NULL,
        FOREIGN KEY(defect_id) REFERENCES defects(id)
    );
    """)
    if c.execute("SELECT COUNT(*) FROM processes").fetchone()[0] == 0:
        c.executemany("""INSERT INTO processes
        (name,department,owner,units,defects,target_rate)
        VALUES(?,?,?,?,?,?)""", [
            ("Invoice Processing","Finance","Process Excellence Lead",4200,118,2.0),
            ("Customer Onboarding","Operations","Quality Manager",3100,164,3.0),
            ("Service Resolution","Support","Service Quality Lead",5800,203,3.0)
        ])
        c.executemany("""INSERT INTO defects
        (process_id,defect_type,description,severity,occurrence,impact_cost,detected_at)
        VALUES(?,?,?,?,?,?,?)""", [
            (1,"Data Error","Incorrect invoice field entered","Medium",42,8400,"2026-09-20"),
            (1,"Mismatch","Purchase order mismatch","High",31,12400,"2026-09-21"),
            (2,"Documentation","Missing customer document","High",58,17400,"2026-09-20"),
            (2,"Verification","Incorrect verification result","Critical",24,21600,"2026-09-21"),
            (3,"Classification","Ticket assigned to wrong category","Medium",73,7300,"2026-09-19"),
            (3,"Rework","Ticket reopened after closure","High",51,15300,"2026-09-21")
        ])
        c.executemany("""INSERT INTO causes
        (defect_id,category,cause,evidence,likelihood)
        VALUES(?,?,?,?,?)""", [
            (1,"People","Manual data entry","High manual-entry volume","High"),
            (1,"Method","No standardized validation checklist","Checklist not mandatory","Medium"),
            (2,"Technology","Purchase order data not synchronized","Manual lookup required","High"),
            (3,"People","Customer instructions unclear","Repeated missing fields","High"),
            (4,"Method","Verification sequence inconsistent","Different reviewers use different steps","High"),
            (5,"Method","Classification rules unclear","Frequent category changes","Medium")
        ])
    c.commit()
    c.close()

def rate(defects, units):
    return (defects / units * 100) if units else 0

@app.route("/")
def dashboard():
    c = db()
    processes = c.execute("SELECT * FROM processes ORDER BY id").fetchall()
    defects = c.execute("""SELECT d.*, p.name process_name
        FROM defects d JOIN processes p ON p.id=d.process_id
        ORDER BY d.impact_cost DESC""").fetchall()
    causes = c.execute("""SELECT ca.*, d.defect_type, p.name process_name
        FROM causes ca JOIN defects d ON d.id=ca.defect_id
        JOIN processes p ON p.id=d.process_id
        ORDER BY ca.id DESC""").fetchall()
    total_units = c.execute("SELECT COALESCE(SUM(units),0) FROM processes").fetchone()[0]
    total_defects = c.execute("SELECT COALESCE(SUM(defects),0) FROM processes").fetchone()[0]
    stats = {
        "processes": len(processes),
        "units": total_units,
        "defects": total_defects,
        "rate": rate(total_defects, total_units),
        "cost": c.execute("SELECT COALESCE(SUM(impact_cost),0) FROM defects").fetchone()[0]
    }
    c.close()
    return render_template("dashboard.html", processes=processes, defects=defects,
                           causes=causes, stats=stats, rate=rate)

@app.route("/processes")
def processes():
    c = db()
    rows = c.execute("SELECT * FROM processes ORDER BY id DESC").fetchall()
    c.close()
    return render_template("processes.html", processes=rows, show_form=False, rate=rate)

@app.route("/processes/new", methods=["GET","POST"])
def process_new():
    if request.method == "POST":
        try:
            vals = (
                request.form["name"].strip(), request.form["department"].strip(),
                request.form["owner"].strip(), int(request.form["units"]),
                int(request.form["defects"]), float(request.form["target_rate"])
            )
            if not vals[0] or not vals[1] or not vals[2] or vals[3] < 0 or vals[4] < 0 or vals[4] > vals[3] or vals[5] < 0:
                raise ValueError
            c = db()
            c.execute("""INSERT INTO processes
                (name,department,owner,units,defects,target_rate)
                VALUES(?,?,?,?,?,?)""", vals)
            c.commit(); c.close()
            flash("Process added.", "success")
            return redirect(url_for("processes"))
        except (ValueError, KeyError):
            flash("Enter valid process data.", "error")
    return render_template("processes.html", processes=[], show_form=True, rate=rate)

@app.route("/defects")
def defects():
    c = db()
    rows = c.execute("""SELECT d.*, p.name process_name
        FROM defects d JOIN processes p ON p.id=d.process_id
        ORDER BY d.impact_cost DESC""").fetchall()
    processes = c.execute("SELECT * FROM processes ORDER BY name").fetchall()
    c.close()
    return render_template("defects.html", defects=rows, processes=processes, show_form=False)

@app.route("/defects/new", methods=["GET","POST"])
def defect_new():
    c = db()
    processes = c.execute("SELECT * FROM processes ORDER BY name").fetchall()
    c.close()
    if request.method == "POST":
        try:
            vals = (
                int(request.form["process_id"]), request.form["defect_type"],
                request.form["description"].strip(), request.form["severity"],
                int(request.form["occurrence"]), float(request.form["impact_cost"]),
                request.form.get("detected_at") or datetime.now().strftime("%Y-%m-%d")
            )
            if not vals[2] or vals[4] < 1 or vals[5] < 0:
                raise ValueError
            c = db()
            c.execute("""INSERT INTO defects
                (process_id,defect_type,description,severity,occurrence,impact_cost,detected_at)
                VALUES(?,?,?,?,?,?,?)""", vals)
            c.commit(); c.close()
            flash("Defect recorded.", "success")
            return redirect(url_for("defects"))
        except (ValueError, KeyError):
            flash("Enter valid defect data.", "error")
    return render_template("defects.html", defects=[], processes=processes, show_form=True)

@app.route("/causes")
def causes():
    c = db()
    rows = c.execute("""SELECT ca.*, d.defect_type, d.description defect_description,
        p.name process_name
        FROM causes ca JOIN defects d ON d.id=ca.defect_id
        JOIN processes p ON p.id=d.process_id
        ORDER BY ca.id DESC""").fetchall()
    defects = c.execute("""SELECT d.*, p.name process_name
        FROM defects d JOIN processes p ON p.id=d.process_id
        ORDER BY d.id DESC""").fetchall()
    c.close()
    return render_template("causes.html", causes=rows, defects=defects, show_form=False)

@app.route("/causes/new", methods=["GET","POST"])
def cause_new():
    c = db()
    defects = c.execute("""SELECT d.*, p.name process_name
        FROM defects d JOIN processes p ON p.id=d.process_id
        ORDER BY d.id DESC""").fetchall()
    c.close()
    if request.method == "POST":
        try:
            vals = (
                int(request.form["defect_id"]), request.form["category"],
                request.form["cause"].strip(), request.form["evidence"].strip(),
                request.form["likelihood"]
            )
            if not vals[2] or not vals[3]:
                raise ValueError
            c = db()
            c.execute("""INSERT INTO causes
                (defect_id,category,cause,evidence,likelihood)
                VALUES(?,?,?,?,?)""", vals)
            c.commit(); c.close()
            flash("Root cause observation added.", "success")
            return redirect(url_for("causes"))
        except (ValueError, KeyError):
            flash("Enter valid cause data.", "error")
    return render_template("causes.html", causes=[], defects=defects, show_form=True)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
