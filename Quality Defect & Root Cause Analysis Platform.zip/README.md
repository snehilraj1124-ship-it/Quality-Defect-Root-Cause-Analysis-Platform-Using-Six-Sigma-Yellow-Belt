# Quality Defect & Root Cause Analysis Platform using Six Sigma Yellow Belt

## Overview

The **Quality Defect & Root Cause Analysis Platform** is a full-stack quality-management application designed around **Six Sigma Yellow Belt** concepts.

The platform extends basic process awareness into structured defect analysis and root-cause investigation. Users can monitor process quality, record defects, quantify defect impact, classify severity, document suspected causes, and capture supporting evidence.

The project follows the practical Yellow Belt improvement mindset:

**Identify → Measure → Analyze → Investigate Causes → Prioritize Improvement**

---

## Objectives

- Track process quality performance
- Record defect occurrences
- Calculate defect rates
- Classify defect severity
- Estimate financial impact
- Document suspected root causes
- Categorize causes using People, Process/Method, Technology and related dimensions
- Record evidence supporting a suspected cause
- Assess cause likelihood
- Prioritize quality problems
- Provide an executive quality dashboard

---

## Six Sigma Yellow Belt Concepts

The project demonstrates:

- Defect identification
- Defect classification
- Basic quality metrics
- Root cause analysis
- Evidence-based problem investigation
- Cause categorization
- Severity analysis
- Defect prioritization
- Continuous improvement
- Team-level quality management

This project is intentionally more analytical than the White Belt project while remaining suitable for Yellow Belt-level process improvement.

---

## Core Modules

### 1. Process Quality Management

Each process contains:

- Process name
- Department
- Process owner
- Units processed
- Defects
- Target defect rate

The system calculates the observed defect rate automatically.

### 2. Defect Register

Users can record:

- Defect type
- Description
- Severity
- Occurrence count
- Estimated impact cost
- Detection date
- Related process

Severity levels include:

- Low
- Medium
- High
- Critical

### 3. Root Cause Analysis

The Root Cause Analysis module captures:

- Related defect
- Cause category
- Suspected cause
- Supporting evidence
- Likelihood

Example categories:

- People
- Method
- Technology
- Measurement
- Environment
- Material

The application does not automatically declare a cause to be the proven root cause; it stores investigation hypotheses and evidence for further validation.

---

## Quality Metrics

### Defect Rate

```text
Defect Rate =
Total Defects / Total Units × 100
```

Example:

```text
Units = 5,000
Defects = 100

Defect Rate =
100 / 5,000 × 100
= 2%
```

### Defect Impact

The platform records estimated impact cost for individual defect observations.

This can represent:

- Rework
- Scrap
- Customer compensation
- Processing cost
- Lost productivity
- Service recovery

---

## Root Cause Investigation Workflow

```text
Process
   ↓
Defect
   ↓
Defect Classification
   ↓
Severity & Impact
   ↓
Cause Identification
   ↓
Evidence Collection
   ↓
Likelihood Assessment
   ↓
Root Cause Validation
   ↓
Improvement Action
```

---

## Sample Data

The application includes demonstration data for processes such as:

| Process | Units | Defects | Target Rate |
|---|---:|---:|---:|
| Invoice Processing | 4,200 | 118 | 2.0% |
| Customer Onboarding | 3,100 | 164 | 3.0% |
| Service Resolution | 5,800 | 203 | 3.0% |

The sample values are for educational demonstration.

---

## Dashboard

The dashboard provides:

- Number of monitored processes
- Total units processed
- Total defects
- Overall defect rate
- Estimated defect impact cost
- High-impact defects
- Recent root-cause observations

This gives quality teams a single view of current problem areas.

---

## Technology Stack

### Backend

- Python
- Flask

### Database

- SQLite
- SQL

### Frontend

- HTML5
- CSS3
- Jinja2

---

## Project Structure

```text
Quality-Defect-Root-Cause-Analysis-Platform/
│
├── app.py
├── requirements.txt
├── README.md
├── schema.sql
├── .gitignore
│
└── templates/
    ├── base.html
    ├── dashboard.html
    ├── processes.html
    ├── defects.html
    └── causes.html
```

---

## Installation

### Clone

```bash
git clone https://github.com/yourusername/Quality-Defect-Root-Cause-Analysis-Platform.git
```

### Enter Project

```bash
cd Quality-Defect-Root-Cause-Analysis-Platform
```

### Create Virtual Environment

Windows:

```bash
python -m venv venv
venv\Scriptsctivate
```

Linux/macOS:

```bash
python3 -m venv venv
source venv/bin/activate
```

### Install

```bash
pip install -r requirements.txt
```

### Run

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

---

## Business Use Cases

### Manufacturing

Track defects, scrap, rework and production-quality issues.

### Finance

Analyze invoice, payment and transaction-processing errors.

### Customer Operations

Analyze onboarding, service and complaint-related defects.

### IT Service Management

Track ticket classification, resolution and reopening defects.

### Supply Chain

Investigate documentation, inventory and fulfillment errors.

### Management Consulting

Create structured defect and root-cause investigation records.

---

## MBA Relevance

The project demonstrates practical concepts in:

- Operations Management
- Quality Management
- Six Sigma
- Business Analytics
- Root Cause Analysis
- Process Improvement
- KPI Management
- Cost of Quality
- Continuous Improvement
- Data-Driven Decision Making

---

## Yellow Belt Learning Progression

### White Belt

```text
Process Awareness
Process Mapping
Waste Identification
Basic Metrics
```

### Yellow Belt

```text
Defect Analysis
Root Cause Analysis
Cause Categorization
Evidence Collection
Problem Prioritization
```

### Green Belt

```text
DMAIC
Process Capability
Cp / Cpk
Control Charts
Statistical Analysis
```

### Black Belt

```text
Predictive Quality
Regression
DOE
Advanced Optimization
Financial Impact Modeling
```

### Master Black Belt

```text
Enterprise Improvement
Portfolio Governance
Continuous Improvement Strategy
Organizational Quality Deployment
```

---

## Future Enhancements

- Pareto defect analysis
- Fishbone diagram builder
- 5 Whys workflow
- DPMO calculator
- Sigma-level calculator
- Cp/Cpk analysis
- Control charts
- FMEA module
- Corrective Action / Preventive Action tracking
- Before-and-after comparison
- Cost of Poor Quality analysis
- Automated reports
- Excel export
- PDF quality reports
- User authentication
- Role-based access control
- PostgreSQL support
- Advanced statistical analytics

---

## Portfolio Value

```text
Six Sigma
   +
Quality Management
   +
Root Cause Analysis
   +
Business Analytics
   +
Operations Management
   +
Software Development
```

The project is suitable for demonstrating practical understanding of Yellow Belt-level quality improvement concepts in an MBA, Business Analytics, Operations, Consulting or Process Excellence portfolio.

---

## Project Highlights

- Process quality monitoring
- Defect register
- Defect-rate calculation
- Severity classification
- Impact-cost tracking
- Root-cause investigation
- Cause categorization
- Evidence capture
- Likelihood assessment
- Quality dashboard
- SQLite database
- Flask application
- Six Sigma Yellow Belt foundation

---

## Author

**Snehil Raj**

B.Tech — Electrical & Electronics Engineering  
VIT Vellore

### Areas of Interest

- Operations Management
- Business Analytics
- Six Sigma
- Quality Management
- Process Improvement
- Energy & Power Systems
- Finance
- Strategic Management
- Data Analytics

---

## Disclaimer

This is an educational implementation of Six Sigma Yellow Belt concepts. Root causes stored in the platform represent investigation hypotheses and should be validated using appropriate evidence and statistical or operational analysis before corrective action is implemented.
