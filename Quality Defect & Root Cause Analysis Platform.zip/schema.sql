CREATE TABLE processes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    department TEXT NOT NULL,
    owner TEXT NOT NULL,
    units INTEGER NOT NULL,
    defects INTEGER NOT NULL,
    target_rate REAL NOT NULL
);

CREATE TABLE defects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    process_id INTEGER NOT NULL,
    defect_type TEXT NOT NULL,
    description TEXT NOT NULL,
    severity TEXT NOT NULL,
    occurrence INTEGER NOT NULL,
    impact_cost REAL NOT NULL,
    detected_at TEXT NOT NULL
);

CREATE TABLE causes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    defect_id INTEGER NOT NULL,
    category TEXT NOT NULL,
    cause TEXT NOT NULL,
    evidence TEXT NOT NULL,
    likelihood TEXT NOT NULL
);
